# lambda_functions/manage_db_resources.py

import json
import pymysql
import boto3
import os
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    # Extract stack_name from the event
    stack_name = event.get('stack_name')
    env = event.get('env')
    if not stack_name:
        return {
            'statusCode': 400,
            'body': json.dumps("Error: 'stack_name' parameter is required.")
        }
    if not env:
        return {
            'statusCode': 400,
            'body': json.dumps("Error: 'env' parameter is required.")
        }
    
    # RDS settings from environment variables
    rds_host = os.environ['RDS_HOST']
    rds_port = int(os.environ['RDS_PORT'])
    master_username = os.environ['MASTER_USERNAME']
    master_password = os.environ['MASTER_PASSWORD']
    
    # Define database and user based on stack_name
    db_name = f"{stack_name}_db"
    db_user = f"{stack_name}_user"
    secrets_manager_secret_name = f"{env}_{stack_name}_db_credentials"
    
    # Generate a secure random password
    import string
    import random
    def generate_password(length=16):
        characters = string.ascii_letters + string.digits + string.punctuation
        # Remove problematic characters for passwords if necessary
        characters = characters.replace("'", "").replace('"', "").replace("\\", "")
        return ''.join(random.choice(characters) for _ in range(length))
    
    db_password = generate_password()
    
    # Connect to RDS
    try:
        connection = pymysql.connect(
            host=rds_host,
            user=master_username,
            password=master_password,
            port=rds_port,
            cursorclass=pymysql.cursors.DictCursor
        )
    except pymysql.MySQLError as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Could not connect to RDS: {str(e)}")
        }
    
    try:
        with connection.cursor() as cursor:
            # Create database
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{db_name}`;")
            # Create user
            cursor.execute(f"""
                CREATE USER IF NOT EXISTS '{db_user}'@'%' IDENTIFIED BY '{db_password}';
            """)
            # Grant privileges
            cursor.execute(f"""
                GRANT ALL PRIVILEGES ON `{db_name}`.* TO '{db_user}'@'%';
            """)
            # Flush privileges
            cursor.execute("FLUSH PRIVILEGES;")
        connection.commit()
    except pymysql.MySQLError as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error executing SQL commands: {str(e)}")
        }
    finally:
        connection.close()
    
    # Store credentials in Secrets Manager
    secrets_client = boto3.client('secretsmanager')
    secret_string = json.dumps({
        "username": db_user,
        "password": db_password
    })
    
    try:
        # Try to create the secret
        secrets_client.create_secret(
            Name=secrets_manager_secret_name,
            SecretString=secret_string
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceExistsException':
            # If secret exists, update it
            secrets_client.update_secret(
                SecretId=secrets_manager_secret_name,
                SecretString=secret_string
            )
        else:
            return {
                'statusCode': 500,
                'body': json.dumps(f"Error storing secret: {str(e)}")
            }
    
    return {
        'statusCode': 200,
        'body': json.dumps(f"Database '{db_name}' and user '{db_user}' created successfully.")
    }
